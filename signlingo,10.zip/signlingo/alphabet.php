<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0c1020">

    <title>SignLingo — Ымдау әліпбиі</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&display=swap">

    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>

<body>

<?php include 'includes/header.php'; ?>

<main class="page-container">

    <section class="page-heading">
        <span class="section-kicker">01 / НЕГІЗДЕР</span>

        <h1>Ымдау әліпбиі<span class="heading-period">.</span></h1>

        <p>Әріптерді таңдап, әліпбимен таныс. Іздеу арқылы өзіңе керекті әріпті тез тап.</p>
    </section>

    <div class="alphabet-layout">

        <section class="panel">

            <div class="panel-heading">
                <div>
                    <h2>Әріптер жинағы</h2>
                    <p>Әріпті таңдау үшін карточканы бас.</p>
                </div>

                <span class="count-badge" id="letterCount">42 әріп</span>
            </div>

            <label class="search-box">
                <span>⌕</span>

                <input
                    id="letterSearch"
                    type="search"
                    placeholder="Әріп іздеу..."
                    autocomplete="off"
                >

                <kbd>Іздеу</kbd>
            </label>

            <div class="alphabet-grid" id="alphabetGrid"></div>

            <p class="empty-message" id="noLetters" hidden>
                Бұл әріп табылмады. Басқа әріпті іздеп көр.
            </p>

        </section>

        <aside class="panel preview-panel">

            <span class="section-kicker">ТАҢДАЛҒАН ӘРІП</span>

            <div class="selected-letter" id="selectedLetter">А</div>

            <h2 id="selectedTitle">А әрпі</h2>

            <p class="preview-description" id="selectedDescription">
                Әріптерді таңдаудан баста. Қол қимылының үлгілерін төмендегі ресурстан көре аласың.
            </p>

            <div class="preview-divider"></div>

            <div class="resource-card">
                <span class="resource-icon">↗</span>

                <h3>Қол қимылдарының үлгілері</h3>

                <p>Қазақ ымдау әліпбиін көрсететін сыртқы оқу ресурсын аш.</p>

                <a
                    class="button button-primary button-full"
                    href="https://soy-le.kz/alphabet/"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    Әліпбиді көру ↗
                </a>
            </div>

            <p class="fine-print">
                Сыртқы ресурс жаңа қойындыда ашылады.
            </p>

        </aside>

    </div>

</main>

<?php include 'includes/footer.php'; ?>

</body>
</html>