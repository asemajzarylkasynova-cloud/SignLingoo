
document.addEventListener("DOMContentLoaded", function () {
    const loginTab = document.getElementById("loginTab");
    const registerTab = document.getElementById("registerTab");

    const nameField = document.getElementById("nameField");
    const fullName = document.getElementById("fullName");

    const authTitle = document.getElementById("authTitle");
    const authSubtitle = document.getElementById("authSubtitle");
    const authSubmit = document.getElementById("authSubmit");
    const formType = document.getElementById("formType");

    function setMode(mode) {
        const isRegister = mode === "register";

        if (!loginTab || !registerTab) return;

        loginTab.classList.toggle("active", !isRegister);
        registerTab.classList.toggle("active", isRegister);

        nameField.hidden = !isRegister;
        fullName.required = isRegister;

        formType.value = mode;

        authTitle.textContent = isRegister
            ? "Бізге қосылғаныңа қуаныштымыз."
            : "Қайта оралғаныңа қуаныштымыз.";

        authSubtitle.textContent = isRegister
            ? "Тіркелу үшін мәліметтеріңді енгіз."
            : "Мәліметтеріңді енгізіп, жалғастыр.";

        authSubmit.textContent = isRegister
            ? "Тіркелу →"
            : "Кіру →";
    }

    if (loginTab && registerTab) {
        loginTab.addEventListener("click", function () {
            setMode("login");
        });

        registerTab.addEventListener("click", function () {
            setMode("register");
        });
    }

    const menuToggle = document.getElementById("menuToggle");
    const mainNav = document.getElementById("mainNav");

    if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", function () {
            const isOpen = mainNav.classList.toggle("open");
            menuToggle.setAttribute("aria-expanded", isOpen);
        });
    }
});
