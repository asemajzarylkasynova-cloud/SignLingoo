</main>

<footer>
    <p>© 2026 SignLingo. Барлық құқықтар қорғалған.</p>
</footer>

<script src="script.js"></script>
</body>
</html>