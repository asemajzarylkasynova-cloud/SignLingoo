<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignLingo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <nav class="navbar">
        <a href="index.php" class="logo">SignLingo</a>

        <div class="nav-links">
            <a href="index.php">Басты бет</a>
            <a href="alphabet.php">Әліпби</a>
            <a href="learn.php">Сабақтар</a>
            <a href="login.php">Кіру</a>
        </div>
    </nav>
</header>

<main>