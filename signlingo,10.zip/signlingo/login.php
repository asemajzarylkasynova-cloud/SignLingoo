
<?php
$errors = [];
$success = '';
$isRegister = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isRegister = ($_POST['form_type'] ?? 'login') === 'register';

    $fullName = trim($_POST['fullName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($isRegister && $fullName === '') {
        $errors[] = 'Аты-жөніңді енгіз.';
    }

    if ($email === '') {
        $errors[] = 'Электрондық пошта енгіз.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Электрондық пошта форматы дұрыс емес.';
    }

    if (strlen($password) < 6) {
        $errors[] = 'Құпиясөз кемінде 6 таңбадан тұруы керек.';
    }

    if (empty($errors)) {
        $success = $isRegister
            ? 'Тіркелу формасы сәтті тексерілді!'
            : 'Кіру формасы сәтті тексерілді!';
    }
}
?>

<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0c1020">

    <title>SignLingo — Аккаунт</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&display=swap">

    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>

<body>

<?php include 'includes/header.php'; ?>

<main class="auth-page">

    <div class="auth-decoration auth-decoration-one"></div>
    <div class="auth-decoration auth-decoration-two"></div>

    <section class="auth-card">

        <a class="auth-brand" href="index.php">
            <span class="brand-mark">S<span>.</span></span>
        </a>

        <span class="section-kicker">SIGNLINGO ҚАУЫМДАСТЫҒЫ</span>

        <h1 id="authTitle">
            <?= $isRegister ? 'Бізге қосылғаныңа қуаныштымыз.' : 'Қайта оралғаныңа қуаныштымыз.' ?>
        </h1>

        <p class="auth-subtitle" id="authSubtitle">
            <?= $isRegister ? 'Тіркелу үшін мәліметтеріңді енгіз.' : 'Мәліметтеріңді енгізіп, жалғастыр.' ?>
        </p>

        <div class="auth-tabs">
            <button type="button" class="auth-tab <?= !$isRegister ? 'active' : '' ?>" id="loginTab">Кіру</button>
            <button type="button" class="auth-tab <?= $isRegister ? 'active' : '' ?>" id="registerTab">Тіркелу</button>
        </div>

        <form id="authForm" method="POST" action="login.php">

            <input type="hidden" name="form_type" id="formType" value="<?= $isRegister ? 'register' : 'login' ?>">

            <div class="form-group" id="nameField" <?= $isRegister ? '' : 'hidden' ?>>
                <label for="fullName">Аты-жөнің</label>
                <input
                    id="fullName"
                    name="fullName"
                    type="text"
                    placeholder="Аты-жөніңді енгіз"
                    autocomplete="name"
                    value="<?= htmlspecialchars($fullName ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    <?= $isRegister ? 'required' : '' ?>
                >
            </div>

            <div class="form-group">
                <label for="email">Электрондық пошта</label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="name@example.com"
                    required
                    autocomplete="email"
                    value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>"
                >
            </div>

            <div class="form-group">
                <label for="password">Құпиясөз</label>
                <input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Кемінде 6 таңба"
                    minlength="6"
                    required
                    autocomplete="current-password"
                >
            </div>

            <button class="button button-primary button-full auth-submit" id="authSubmit" type="submit">
                <?= $isRegister ? 'Тіркелу →' : 'Кіру →' ?>
            </button>

            <?php if (!empty($errors)): ?>
                <div class="form-message" role="alert">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($success !== ''): ?>
                <p class="form-message" role="status">
                    <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
                </p>
            <?php endif; ?>

        </form>

        <div class="auth-divider"><span>НЕМЕСЕ</span></div>

        <p class="auth-footnote">
            Бұл — серверлік тексеруі бар оқу жобасы. Әзірге аккаунт деректері дерекқорға сақталмайды.
        </p>

        <a class="back-link" href="index.php">← Басты бетке оралу</a>

    </section>
</main>

<?php include 'includes/footer.php'; ?>

</body>
</html>
