
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0c1020">
    <title>SignLingo — Сабақтар</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>

<?php include 'includes/header.php'; ?>

<main class="page-container">
    <section class="page-heading">
        <span class="section-kicker">02 / ТӘЖІРИБЕ</span>
        <h1>Үйрену кеңістігі<span class="heading-period">.</span></h1>
        <p>Тақырыпты таңда, жаңа белгілермен таныс және білгендеріңді қайтала.</p>
    </section>

    <div class="lesson-tools">
        <label class="search-box lesson-search">
            <span>⌕</span>
            <input id="lessonSearch" type="search" placeholder="Сабақ немесе тақырып іздеу..." autocomplete="off">
        </label>

        <select id="lessonFilter" aria-label="Сабақ санатын таңдау">
            <option value="all">Барлық тақырып</option>
            <option value="beginner">Бастапқы деңгей</option>
            <option value="daily">Күнделікті қарым-қатынас</option>
        </select>
    </div>

    <div class="lesson-results">
        <p class="results-label" id="resultsLabel">БАРЛЫҚ САБАҚ</p>
        <p class="empty-message" id="noLessons" hidden>Сәйкес сабақ табылмады. Іздеуді өзгертіп көр.</p>
    </div>

    <section class="lesson-grid" id="lessonGrid">

        <article class="lesson-card" data-category="beginner">
            <div class="lesson-art-card art-purple">
                <span class="lesson-index">LESSON 01</span>
                <span class="lesson-emoji">👋</span>
                <span class="lesson-art-caption">СӘЛЕМДЕСУ</span>
            </div>
            <div class="lesson-body">
                <span class="lesson-tag">Бастапқы деңгей</span>
                <h2>Сәлемдесу</h2>
                <p>Сәлем, сау бол, рақмет сияқты күнделікті сөздерге қатысты белгілерді ізде.</p>
                <a class="button button-primary button-full" href="https://www.youtube.com/results?search_query=қазақша+ымдау+тілі+сәлемдесу" target="_blank" rel="noopener noreferrer">Сабақты іздеу ↗</a>
            </div>
        </article>

        <article class="lesson-card" data-category="daily">
            <div class="lesson-art-card art-green">
                <span class="lesson-index">LESSON 02</span>
                <span class="lesson-emoji">⌂</span>
                <span class="lesson-art-caption">ОТБАСЫ</span>
            </div>
            <div class="lesson-body">
                <span class="lesson-tag">Күнделікті қарым-қатынас</span>
                <h2>Отбасы</h2>
                <p>Отбасы мүшелерінің атауларын және күнделікті қолданылатын белгілерді үйрен.</p>
                <a class="button button-primary button-full" href="https://www.youtube.com/results?search_query=қазақша+ымдау+тілі+отбасы" target="_blank" rel="noopener noreferrer">Сабақты іздеу ↗</a>
            </div>
        </article>

        <article class="lesson-card" data-category="daily">
            <div class="lesson-art-card art-orange">
                <span class="lesson-index">LESSON 03</span>
                <span class="lesson-emoji">▤</span>
                <span class="lesson-art-caption">МЕКТЕП</span>
            </div>
            <div class="lesson-body">
                <span class="lesson-tag">Күнделікті қарым-қатынас</span>
                <h2>Мектеп және оқу</h2>
                <p>Мектеп, мұғалім, оқушы, кітап және сабақ тақырыптарына қатысты белгілерді ізде.</p>
                <a class="button button-primary button-full" href="https://www.youtube.com/results?search_query=қазақша+ымдау+тілі+мектеп" target="_blank" rel="noopener noreferrer">Сабақты іздеу ↗</a>
            </div>
        </article>

        <article class="lesson-card" data-category="beginner">
            <div class="lesson-art-card art-blue">
                <span class="lesson-index">LESSON 04</span>
                <span class="lesson-emoji">123</span>
                <span class="lesson-art-caption">САНДАР</span>
            </div>
            <div class="lesson-body">
                <span class="lesson-tag">Бастапқы деңгей</span>
                <h2>Сандар</h2>
                <p>Сандар мен қарапайым есептеуге қатысты ымдау үлгілерін ізде.</p>
                <a class="button button-primary button-full" href="https://www.youtube.com/results?search_query=қазақша+ымдау+тілі+сандар" target="_blank" rel="noopener noreferrer">Сабақты іздеу ↗</a>
            </div>
        </article>

        <article class="lesson-card" data-category="daily">
            <div class="lesson-art-card art-pink">
                <span class="lesson-index">LESSON 05</span>
                <span class="lesson-emoji">♡</span>
                <span class="lesson-art-caption">СЕЗІМДЕР</span>
            </div>
            <div class="lesson-body">
                <span class="lesson-tag">Күнделікті қарым-қатынас</span>
                <h2>Сезімдер мен көңіл күй</h2>
                <p>Сезімдерді және көңіл күйді білдіруге арналған белгілерді қарастыр.</p>
                <a class="button button-primary button-full" href="https://www.youtube.com/results?search_query=қазақша+ымдау+тілі+сезімдер" target="_blank" rel="noopener noreferrer">Сабақты іздеу ↗</a>
            </div>
        </article>

        <article class="lesson-card" data-category="beginner">
            <div class="lesson-art-card art-yellow">
                <span class="lesson-index">LESSON 06</span>
                <span class="lesson-emoji">Aa</span>
                <span class="lesson-art-caption">ДАКТИЛЬ ӘЛІПБИІ</span>
            </div>
            <div class="lesson-body">
                <span class="lesson-tag">Бастапқы деңгей</span>
                <h2>Дактиль әліпбиі</h2>
                <p>Әріптерді қол қимылы арқылы көрсету тәсілімен таныс.</p>
                <a class="button button-primary button-full" href="https://soy-le.kz/alphabet/" target="_blank" rel="noopener noreferrer">Әліпбиді ашу ↗</a>
            </div>
        </article>

    </section>
</main>

<?php include 'includes/footer.php'; ?>

</body>
</html>
