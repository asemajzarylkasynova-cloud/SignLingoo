
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0c1020">
    <meta name="description" content="SignLingo — қазақ ымдау тілін үйренуге арналған оқу платформасы.">

    <title>SignLingo — Ымдау тілін үйрен</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>

<?php include 'includes/header.php'; ?>

<main>
    <section class="hero">
        <div class="hero-glow"></div>

        <div class="hero-inner">
            <div class="hero-copy">
                <div class="announcement">
                    <span class="status-dot"></span>
                    Қолжетімді білім · Ортақ мүмкіндік
                </div>

                <h1>Сөзсіз де<br>түсінуге <span class="gradient-text">болады.</span></h1>

                <p class="hero-description">
                    Ымдау тілінің әлемін аш. Жаңа белгілерді үйрен,
                    қарым-қатынас шекарасын кеңейт және адамдарды
                    түсінуге бір қадам жақында.
                </p>

                <div class="hero-buttons">
                    <a class="button button-primary" href="alphabet.php">Үйренуді бастау ↗</a>
                    <a class="button button-secondary" href="learn.php">Сабақтарды көру</a>
                </div>

                <div class="hero-note">
                    <span class="note-check">✓</span>
                    Өз қарқыныңмен үйрен
                    <span class="note-check">✓</span>
                    Күн сайын дамы
                </div>
            </div>

            <div class="hero-visual">
                <div class="orbit orbit-one"></div>
                <div class="orbit orbit-two"></div>

                <div class="visual-center">
                    <span class="visual-spark spark-one">✳</span>
                    <span class="visual-hand">🤟</span>
                    <span class="visual-caption">COMMUNICATION<br>WITHOUT BARRIERS</span>
                    <span class="visual-spark spark-two">✦</span>
                </div>

                <div class="floating-card floating-top">
                    <span class="floating-icon">✳</span>
                    <span>
                        <strong>Түсіністік</strong>
                        <small>Бәрімізге ортақ</small>
                    </span>
                </div>

                <div class="floating-card floating-bottom">
                    <span class="floating-icon green-icon">✓</span>
                    <span>
                        <strong>Жаңа дағды</strong>
                        <small>Бір қадам алға</small>
                    </span>
                </div>
            </div>
        </div>

        <div class="hero-bottom">
            <span>БІРГЕ ҮЙРЕНЕМІЗ</span>
            <i></i>
            <span>БІРГЕ ТҮСІНЕМІЗ</span>
            <i></i>
            <span>БІРГЕ ДАМЫЙМЫЗ</span>
        </div>
    </section>

    <section class="section learning-section">
        <div class="section-heading">
            <div>
                <span class="section-kicker">БІРІНШІ ҚАДАМ</span>
                <h2>Өзіңе жақын жолды таңда.</h2>
            </div>
            <p>Әліпбиден бастап күнделікті қарым-қатынасқа дейін — бәрі бір жерде.</p>
        </div>

        <div class="path-grid">
            <a class="path-card" href="alphabet.php">
                <div class="path-card-top">
                    <span class="path-number">01 / ӘЛІПБИ</span>
                    <span class="path-arrow">↗</span>
                </div>

                <div class="path-art alphabet-art">
                    <span class="letter-tile tile-a">А</span>
                    <span class="letter-tile tile-b">Ә</span>
                    <span class="letter-tile tile-c">Қ</span>
                    <span class="letter-tile tile-d">Ө</span>
                </div>

                <div class="path-card-content">
                    <h3>Әліпбиден баста</h3>
                    <p>Әріптермен танысып, дактиль әліпбиін зертте.</p>
                    <span class="text-link">Әліпбиге өту →</span>
                </div>
            </a>

            <a class="path-card" href="learn.php">
                <div class="path-card-top">
                    <span class="path-number">02 / САБАҚТАР</span>
                    <span class="path-arrow">↗</span>
                </div>

                <div class="path-art lesson-art">
                    <div class="lesson-window">
                        <div class="window-dots"><i></i><i></i><i></i></div>
                        <div class="window-person">▶</div>
                        <div class="window-lines"><i></i><i></i><i></i></div>
                    </div>
                </div>

                <div class="path-card-content">
                    <h3>Көріп үйрен</h3>
                    <p>Күнделікті сөздер мен пайдалы тақырыптарды меңгер.</p>
                    <span class="text-link">Сабақтарды ашу →</span>
                </div>
            </a>

            <a class="path-card" href="login.php">
                <div class="path-card-top">
                    <span class="path-number">03 / ЖЕКЕ ДАМУ</span>
                    <span class="path-arrow">↗</span>
                </div>

                <div class="path-art progress-art">
                    <div class="progress-ring">
                        <div class="progress-ring-inner">
                            <span>+</span>
                            <small>ЖАҢА МАҚСАТ</small>
                        </div>
                    </div>
                </div>

                <div class="path-card-content">
                    <h3>Өз жолыңды баста</h3>
                    <p>Оқуға уақыт бөліп, үйренгендеріңді жүйелі қайтала.</p>
                    <span class="text-link">Бастау →</span>
                </div>
            </a>
        </div>
    </section>

    <section class="mission-section">
        <div class="mission-mark">“</div>

        <div>
            <span class="section-kicker">БІЗДІҢ МИССИЯ</span>
            <h2>Қарым-қатынас — әр адамның құқығы.</h2>
            <p>
                SignLingo ымдау тілін үйренуге қызығушылықты арттыруға,
                адамдар арасындағы түсіністікті дамытуға және білімді
                барынша қолжетімді етуге бағытталған.
            </p>
        </div>

        <a class="mission-link" href="alphabet.php" aria-label="Әліпбиге өту">↗</a>
    </section>

    <section class="final-cta">
        <span class="section-kicker">СЕНІҢ КЕЗЕГІҢ</span>
        <h2>Алғашқы белгіңді<br><span class="gradient-text">бүгін үйрен.</span></h2>
        <p>Кішкентай қадам да үлкен түсіністікке бастайды.</p>
        <a class="button button-primary" href="alphabet.php">Әліпбиге өту ↗</a>
        <span class="cta-watermark">S.</span>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
