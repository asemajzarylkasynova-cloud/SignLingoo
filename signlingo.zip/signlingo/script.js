
document.addEventListener("DOMContentLoaded", () => {// 1. Мобильді навигация
    const menuToggle = document.getElementById("menuToggle");
    const mainNav = document.getElementById("mainNav");

    if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
            const opened = mainNav.classList.toggle("open");

            menuToggle.setAttribute("aria-expanded", String(opened));
            menuToggle.setAttribute(
                "aria-label",
                opened ? "Мәзірді жабу" : "Мәзірді ашу"
            );
        });

        mainNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                mainNav.classList.remove("open");
                menuToggle.setAttribute("aria-expanded", "false");
                menuToggle.setAttribute("aria-label", "Мәзірді ашу");
            });
        });
    }


    const alphabetGrid = document.getElementById("alphabetGrid");
    const letterSearch = document.getElementById("letterSearch");
    const selectedLetter = document.getElementById("selectedLetter");
    const selectedTitle = document.getElementById("selectedTitle");
    const selectedDescription = document.getElementById("selectedDescription");
    const noLetters = document.getElementById("noLetters");
    const letterCount = document.getElementById("letterCount");

    const alphabet = [
        "А", "Ә", "Б", "В", "Г", "Ғ", "Д", "Е", "Ё", "Ж",
        "З", "И", "Й", "К", "Қ", "Л", "М", "Н", "Ң", "О",
        "Ө", "П", "Р", "С", "Т", "У", "Ұ", "Ү", "Ф", "Х",
        "Һ", "Ц", "Ч", "Ш", "Щ", "Ъ", "Ы", "І", "Ь", "Э",
        "Ю", "Я"
    ];

    let activeLetter = "А";

    function renderAlphabet(query = "") {
        if (!alphabetGrid) return;

        const normalizedQuery = query.trim().toLocaleLowerCase("kk");
        const matches = alphabet.filter(letter =>
            letter.toLocaleLowerCase("kk").includes(normalizedQuery)
        );

        alphabetGrid.replaceChildren();

        matches.forEach(letter => {
            const button = document.createElement("button");

            button.type = "button";
            button.className = "letter-card";
            button.textContent = letter;
            button.setAttribute("aria-label", `${letter} әрпін таңдау`);
            button.setAttribute(
                "aria-pressed",
                String(letter === activeLetter)
            );

            if (letter === activeLetter) {
                button.classList.add("selected");
            }

            button.addEventListener("click", () => {
                activeLetter = letter;

                if (selectedLetter) selectedLetter.textContent = letter;
                if (selectedTitle) selectedTitle.textContent = `${letter} әрпі`;

                if (selectedDescription) {
                    selectedDescription.textContent =
                        `Сен ${letter} әрпін таңдадың. Қол қимылының үлгісін көру үшін «Әліпбиді көру» батырмасын бас.`;
                }

                renderAlphabet(letterSearch ? letterSearch.value : "");
            });

            alphabetGrid.appendChild(button);
        });

        if (noLetters) noLetters.hidden = matches.length > 0;
        if (letterCount) letterCount.textContent = `${matches.length} әріп`;
    }

    if (alphabetGrid) {
        renderAlphabet();

        if (letterSearch) {
            letterSearch.addEventListener("input", () => {
                renderAlphabet(letterSearch.value);
            });
        }
    }


    const lessonSearch = document.getElementById("lessonSearch");
    const lessonFilter = document.getElementById("lessonFilter");
    const lessonCards = [...document.querySelectorAll(".lesson-card")];
    const noLessons = document.getElementById("noLessons");
    const resultsLabel = document.getElementById("resultsLabel");

    function filterLessons() {
        if (!lessonCards.length) return;

        const query = lessonSearch
            ? lessonSearch.value.trim().toLocaleLowerCase("kk")
            : "";

        const category = lessonFilter ? lessonFilter.value : "all";
        let visible = 0;

        lessonCards.forEach(card => {
            const text = card.textContent.toLocaleLowerCase("kk");
            const matchesText = text.includes(query);
            const matchesCategory =
                category === "all" || card.dataset.category === category;

            const show = matchesText && matchesCategory;
            card.hidden = !show;

            if (show) visible++;
        });

        if (noLessons) noLessons.hidden = visible !== 0;

        if (resultsLabel) {
            resultsLabel.textContent = `ТАБЫЛДЫ: ${visible} САБАҚ`;
        }
    }

    if (lessonSearch) {
        lessonSearch.addEventListener("input", filterLessons);
    }

    if (lessonFilter) {
        lessonFilter.addEventListener("change", filterLessons);
    }

    if (lessonCards.length) filterLessons();


    const authForm = document.getElementById("authForm");
    const loginTab = document.getElementById("loginTab");
    const registerTab = document.getElementById("registerTab");
    const authTitle = document.getElementById("authTitle");
    const authSubtitle = document.getElementById("authSubtitle");
    const authSubmit = document.getElementById("authSubmit");
    const nameField = document.getElementById("nameField");
    const fullName = document.getElementById("fullName");
    const password = document.getElementById("password");
    const authMessage = document.getElementById("authMessage");

    let authMode = "login";

    function setAuthMode(mode) {
        authMode = mode;

        const isRegister = mode === "register";

        if (authTitle) {
            authTitle.textContent = isRegister
                ? "Өз аккаунтыңды баста."
                : "Қайта оралғаныңа қуаныштымыз.";
        }

        if (authSubtitle) {
            authSubtitle.textContent = isRegister
                ? "Жаңа аккаунт жасау үшін мәліметтерді енгіз."
                : "Мәліметтеріңді енгізіп, жалғастыр.";
        }

        if (authSubmit) {
            authSubmit.textContent = isRegister
                ? "Тіркелу →"
                : "Кіру →";
        }

        if (nameField) nameField.hidden = !isRegister;
        if (fullName) fullName.required = isRegister;

        if (password) {
            password.autocomplete = isRegister
                ? "new-password"
                : "current-password";
        }

        if (loginTab) loginTab.classList.toggle("active", !isRegister);
        if (registerTab) registerTab.classList.toggle("active", isRegister);

        if (authMessage) {
            authMessage.textContent = "";
            authMessage.classList.remove("error");
        }
    }

    if (loginTab) {
        loginTab.addEventListener("click", () => setAuthMode("login"));
    }

    if (registerTab) {
        registerTab.addEventListener("click", () => setAuthMode("register"));
    }

    if (authForm) {
        authForm.addEventListener("submit", event => {
            event.preventDefault();

            if (!authForm.reportValidity()) return;

            if (authMessage) {
                authMessage.classList.remove("error");

                if (authMode === "register") {
                    const name = fullName.value.trim();

                    if (!name) {
                        fullName.focus();
                        return;
                    }

                    authMessage.textContent =
                        `${name}, форма сәтті толтырылды. ` +
                        "Бұл демонстрациялық нұсқа: аккаунт серверге сақталған жоқ.";
                } else {
                    authMessage.textContent =
                        "Интерфейс тексерілді. Нақты кіру үшін серверлік авторизация қажет.";
                }
            }
        });
    }
});
